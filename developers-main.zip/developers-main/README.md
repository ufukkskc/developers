# developers

This is the remote repository for the academy devs (students)

The purpose of this repository is for students to: 
1. Practice forking projects to their GitHub accounts. 
2. Cloning the project to their local machine. 
3. Commit updates.
4. Push changes back to their remote repository. 
